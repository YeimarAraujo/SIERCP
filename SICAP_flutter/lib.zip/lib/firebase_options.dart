import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyCF0Jv68Lq12yRnwEDGuxHaESViD6p_NzI',
    appId: '1:153485090858:web:1ef9810ca0e4a2d3aba353',
    messagingSenderId: '153485090858',
    projectId: 'siercp',
    authDomain: 'siercp.firebaseapp.com',
    storageBucket: 'siercp.firebasestorage.app',
    measurementId: 'G-5WVX8F0X6Y',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDlAVO9Q-IMO_HjnkwGGjmub-zEOPgfTAI',
    appId: '1:153485090858:android:f3a38d0d69a43e9eaba353',
    messagingSenderId: '153485090858',
    projectId: 'siercp',
    storageBucket: 'siercp.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAp9H6i-Jy4HSZrLAJ6-UD4NddzqCudJWE',
    appId: '1:153485090858:ios:5b6ad2b610661441aba353',
    messagingSenderId: '153485090858',
    projectId: 'siercp',
    storageBucket: 'siercp.firebasestorage.app',
    iosBundleId: 'com.example.siercp',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyCko1zxXGCrMd4gtVLn_XpvA4Rgwn1GpVQ',
    appId: '1:153485090858:ios:5b6ad2b610661441aba353',
    messagingSenderId: '153485090858',
    projectId: 'siercp',
    storageBucket: 'siercp.firebasestorage.app',
    iosBundleId: 'com.example.siercp',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyCF0Jv68Lq12yRnwEDGuxHaESViD6p_NzI',
    appId: '1:153485090858:web:27ebf825ac55f41aaba353',
    messagingSenderId: '153485090858',
    projectId: 'siercp',
    authDomain: 'siercp.firebaseapp.com',
    storageBucket: 'siercp.firebasestorage.app',
    measurementId: 'G-256MTESX2C',
  );
}
